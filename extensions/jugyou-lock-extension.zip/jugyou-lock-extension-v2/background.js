// ============================================================
//  授業モニター ロック - background.js
//  Manifest V3 Service Worker
// ============================================================

const STUDENT_PAGE_URL = 'https://umaki-ops.github.io/classmonitor/student.html';

// Firebaseの設定はstudent.htmlのURLパラメータから動的に取得するため
// ここには書きません（student.html起動時に拡張機能へ送信されます）

// --------------------------------------------------------
// 状態管理
// --------------------------------------------------------
let lockState = {
  active: false,       // セッション参加中 = ロック有効
  studentTabId: null,  // 授業モニタータブのID
  sessionId: null,
  firebaseConfig: null,
};

// Firebase のリスナーを保持（Service Worker内ではfetchベースでポーリング）
let pollingInterval = null;
let lastKnownSessionActive = false;

// --------------------------------------------------------
// 起動時に保存済み状態を復元
// --------------------------------------------------------
chrome.storage.session.get(['lockState'], (result) => {
  if (result.lockState) {
    lockState = { ...lockState, ...result.lockState };
    if (lockState.active) {
      startPolling();
    }
  }
});

// --------------------------------------------------------
// content.js からのメッセージ受信
// student.html が読み込まれると、URLパラメータを送ってくる
// --------------------------------------------------------
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'SESSION_JOINED') {
    // 生徒がセッションに参加した
    const { sessionId, firebaseConfig } = message;
    lockState.studentTabId = sender.tab.id;
    lockState.sessionId = sessionId;
    lockState.firebaseConfig = firebaseConfig;
    lockState.active = true;
    saveState();
    startPolling();
    enforceTabLock();
    updateIcon(true);
    sendResponse({ ok: true });
  }

  if (message.type === 'SESSION_LEFT') {
    // セッション終了
    releaseLock();
    sendResponse({ ok: true });
  }

  if (message.type === 'GET_STATE') {
    sendResponse({ lockState });
  }

  return true; // 非同期レスポンスのため
});

// --------------------------------------------------------
// タブ監視: 新しいタブが開かれたら閉じる
// --------------------------------------------------------
chrome.tabs.onCreated.addListener((tab) => {
  if (!lockState.active) return;
  // 授業モニタータブ自身の生成は許可
  if (tab.id === lockState.studentTabId) return;

  // 新しいタブを即座に閉じて授業モニタータブにフォーカス
  chrome.tabs.remove(tab.id, () => {
    focusStudentTab();
  });
});

// --------------------------------------------------------
// タブ監視: 他のタブがアクティブになったら授業タブに戻す
// --------------------------------------------------------
chrome.tabs.onActivated.addListener(({ tabId }) => {
  if (!lockState.active) return;
  if (tabId === lockState.studentTabId) return;

  // 授業タブ以外がフォーカスされたら即座に戻す
  focusStudentTab();
});

// --------------------------------------------------------
// タブ監視: 授業タブが閉じられたら再度開く
// --------------------------------------------------------
chrome.tabs.onRemoved.addListener((tabId) => {
  if (!lockState.active) return;
  if (tabId !== lockState.studentTabId) return;

  // 授業タブが閉じられた → 再度開く
  reopenStudentTab();
});

// --------------------------------------------------------
// URLナビゲーション監視: 授業タブで別URLに移動しようとしたら戻す
// --------------------------------------------------------
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (!lockState.active) return;
  if (tabId !== lockState.studentTabId) return;
  // 授業タブ自身のURL変更は許可（student.html内のナビゲーション等）
  // ただし完全に別のドメインに移動しようとしたら戻す
  if (changeInfo.url && !isStudentPageUrl(changeInfo.url)) {
    chrome.tabs.update(tabId, { url: buildStudentUrl() });
  }
});

// --------------------------------------------------------
// ヘルパー: 授業タブにフォーカス
// --------------------------------------------------------
function focusStudentTab() {
  if (!lockState.studentTabId) return;
  chrome.tabs.get(lockState.studentTabId, (tab) => {
    if (chrome.runtime.lastError || !tab) {
      reopenStudentTab();
      return;
    }
    chrome.tabs.update(lockState.studentTabId, { active: true });
    chrome.windows.update(tab.windowId, { focused: true });
  });
}

// --------------------------------------------------------
// ヘルパー: 授業タブを再オープン
// --------------------------------------------------------
function reopenStudentTab() {
  if (!lockState.sessionId || !lockState.firebaseConfig) return;
  const url = buildStudentUrl();
  chrome.tabs.create({ url, active: true }, (tab) => {
    lockState.studentTabId = tab.id;
    saveState();
  });
}

// --------------------------------------------------------
// ヘルパー: student.html の URL を組み立て
// --------------------------------------------------------
function buildStudentUrl() {
  if (!lockState.firebaseConfig || !lockState.sessionId) return STUDENT_PAGE_URL;
  const cfg = lockState.firebaseConfig;
  return `${STUDENT_PAGE_URL}?session=${lockState.sessionId}&db=${encodeURIComponent(cfg.databaseURL)}&apiKey=${encodeURIComponent(cfg.apiKey)}&projectId=${encodeURIComponent(cfg.projectId)}`;
}

// --------------------------------------------------------
// ヘルパー: URLが授業ページか判定
// --------------------------------------------------------
function isStudentPageUrl(url) {
  try {
    const u = new URL(url);
    const base = new URL(STUDENT_PAGE_URL);
    return u.hostname === base.hostname && u.pathname === base.pathname;
  } catch {
    return false;
  }
}

// --------------------------------------------------------
// ヘルパー: すべての不要タブを閉じる（ロック開始時）
// --------------------------------------------------------
function enforceTabLock() {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => {
      if (tab.id !== lockState.studentTabId) {
        chrome.tabs.remove(tab.id);
      }
    });
  });
}

// --------------------------------------------------------
// Firebase セッション監視（ポーリング方式）
// Service Worker はWebSocketを保持できないためREST APIでポーリング
// --------------------------------------------------------
function startPolling() {
  stopPolling();
  // 5秒ごとにFirebaseのREST APIでセッション状態を確認
  pollingInterval = setInterval(checkSessionStatus, 5000);
  checkSessionStatus(); // 即時実行
}

function stopPolling() {
  if (pollingInterval) {
    clearInterval(pollingInterval);
    pollingInterval = null;
  }
}

async function checkSessionStatus() {
  if (!lockState.sessionId || !lockState.firebaseConfig) return;
  try {
    const { databaseURL, apiKey } = lockState.firebaseConfig;
    const url = `${databaseURL}/sessions/${lockState.sessionId}/active.json?auth=${apiKey}`;
    const res = await fetch(url);
    if (!res.ok) return;
    const data = await res.json();

    if (data === false || data === null) {
      // セッション終了 → ロック解除
      if (lastKnownSessionActive) {
        lastKnownSessionActive = false;
        releaseLock();
      }
    } else {
      lastKnownSessionActive = true;
    }
  } catch (e) {
    console.warn('[授業ロック] セッション確認エラー:', e);
  }
}

// --------------------------------------------------------
// ロック解除
// --------------------------------------------------------
function releaseLock() {
  lockState.active = false;
  lockState.studentTabId = null;
  lockState.sessionId = null;
  lockState.firebaseConfig = null;
  stopPolling();
  saveState();
  updateIcon(false);
}

// --------------------------------------------------------
// 状態を保存
// --------------------------------------------------------
function saveState() {
  chrome.storage.session.set({ lockState });
}

// --------------------------------------------------------
// アイコンを更新（ロック中は赤、解除中は通常）
// --------------------------------------------------------
function updateIcon(locked) {
  chrome.action.setBadgeText({ text: locked ? '🔒' : '' });
  chrome.action.setBadgeBackgroundColor({ color: locked ? '#ef4444' : '#3b82f6' });
}
