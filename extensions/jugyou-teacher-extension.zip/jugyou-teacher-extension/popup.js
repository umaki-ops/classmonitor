// popup.js - 教員用拡張機能

const TEACHER_URL = 'https://umaki-ops.github.io/classmonitor/teacher.html';

// URL表示
document.getElementById('url-display').textContent = TEACHER_URL;

// 同じタブで開く（すでに teacher.html が開いていればそのタブを使う）
document.getElementById('open-same').addEventListener('click', () => {
  chrome.tabs.query({}, (tabs) => {
    const existing = tabs.find(t => t.url && t.url.startsWith(TEACHER_URL));
    if (existing) {
      // すでに開いているタブをフォーカス
      chrome.tabs.update(existing.id, { active: true });
      chrome.windows.update(existing.windowId, { focused: true });
    } else {
      // 新しいタブで開く
      chrome.tabs.create({ url: TEACHER_URL });
    }
    window.close();
  });
});

// 常に新しいタブで開く
document.getElementById('open-new').addEventListener('click', () => {
  chrome.tabs.create({ url: TEACHER_URL });
  window.close();
});
